./test_SDL exp1 350

